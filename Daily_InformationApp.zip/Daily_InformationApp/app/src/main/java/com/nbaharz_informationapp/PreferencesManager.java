package com.nbaharz_informationapp;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class PreferencesManager {

    private static final String PREFS_NAME = "newPrefs"; // Uygulamanızın ihtiyacına göre değiştirin
    private static final String LAST_CHECKED_DATE_KEY = "last_checked_date";

    private SharedPreferences preferences;
    public PreferencesManager(Context context) {
        this.preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String getLastCheckedDate() {
        return preferences.getString(LAST_CHECKED_DATE_KEY, "");
    }

    public void saveLastCheckedDate(String lastCheckedDate) {
        preferences.edit().putString(LAST_CHECKED_DATE_KEY, currentDate()).apply();
    }
    public String currentDate() {
        return new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Calendar.getInstance().getTime());
        //return "20231230";
    }

}
