package com.nbaharz_informationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.Calendar;



public class MainActivity extends AppCompatActivity {
    private Button factButton;
    private Button quotButton;
    private Button todaysInfo;
    private SharedPreferences preferences;
    private HistoryDatabaseHelper historyDatabaseHelper;
    private DatabaseHelper databaseHelper;
    private OpenNewActivity pageNavigator;
    private boolean isCategorySelected=false;
    private PreferencesManager preferencesManager;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createNotificationChannel();
        Intent intent = new Intent(MainActivity.this, SendNotification.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this,0,intent, PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY, 19);
        calendar.set(Calendar.MINUTE, 7);
        calendar.set(Calendar.SECOND, 0);

        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
        //preferences = getApplicationContext().getSharedPreferences("ny_refs", Context.MODE_PRIVATE);
        preferencesManager = new PreferencesManager(getApplicationContext());
        historyDatabaseHelper = new HistoryDatabaseHelper(MainActivity.this);
        databaseHelper = new DatabaseHelper(MainActivity.this);
        pageNavigator = new OpenNewActivity(this);

        // Bu kısımda findViewById ile bulunan nesne View türünde olduğu için
        // onu Button türüne dönüştürmek için (Button) kullanıyoruz.
        factButton = (Button) findViewById(R.id.btnFact);
        quotButton = (Button) findViewById(R.id.btnQuot);
        todaysInfo =(Button) findViewById(R.id.todaysInfo);

        //final String currentDate = currentDate();
        //final String lastCheckedDate = preferences.getString("last_checked_date", "");

        final String currentDate = preferencesManager.currentDate();
        final String lastCheckedDate = preferencesManager.getLastCheckedDate();

        if (!currentDate.equals(lastCheckedDate)) {
            isCategorySelected = false;

        } else {
            isCategorySelected = true;
        }

        factButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pageNavigator.openNewPage(FactsWindow.class,null);
            }
        });

        quotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isCategorySelected)
                {
                String quote = databaseHelper.getValue(databaseHelper.getCOLUMN_QUOTE());

                pageNavigator.openNewPage(InfoView.class,quote);
                preferencesManager.saveLastCheckedDate(preferencesManager.currentDate());
                isCategorySelected = true;

                }
                else{
                    Toast.makeText(MainActivity.this, "Category already s elected", Toast.LENGTH_SHORT).show();
                }

                //Quote da database'den gelmeli.
            }
        });


        todaysInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    final String currentDate = preferencesManager.currentDate();
                    final String lastCheckedDate = preferencesManager.getLastCheckedDate();
                    Log.d("Dates","Current Date:"+currentDate);
                    Log.d("Dates","Last Checked Date:"+lastCheckedDate);

                    if (lastCheckedDate.equals(currentDate)) {
                        // Eğer lastCheckedDate ve currentDate eşitse
                        String info = historyDatabaseHelper.getValueOfLastRecord("RECEIVED_INFO");
                        pageNavigator.openNewPage(InfoView.class, info);

                        // İşlemlerinizi buraya ekleyin.
                    } else {
                        pageNavigator.openNewPage(InfoView.class, "Today's category hasn't chosen yet.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private void createNotificationChannel(){
        String name = "DailyReminder";
        String description ="Channel for reminder receive info";
        int importance= NotificationManager.IMPORTANCE_DEFAULT;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("myChannel",name,importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

    }


}

