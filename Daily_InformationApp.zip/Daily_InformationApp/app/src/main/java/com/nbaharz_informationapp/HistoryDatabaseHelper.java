package com.nbaharz_informationapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class HistoryDatabaseHelper extends SQLiteOpenHelper {

    private String COLUMN_INFO = "RECEIVED_INFO";
    private String TABLE = "RECEIVED_INFO";
    private String COLUMN_ID ="ID";
    public HistoryDatabaseHelper(@Nullable Context context) {
        super(context, "InfoHistory.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement ="CREATE TABLE " +TABLE+ "(" +COLUMN_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+COLUMN_INFO+ " TEXT)";
        db.execSQL(createTableStatement);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public void addRecord(String text,String columnName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues info = new ContentValues();
        info.put(columnName, text);

        long result = db.insert(TABLE, null, info);
    }
    @SuppressLint("Range")
    public String getValueOfLastRecord(String columnName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + columnName + " FROM " + TABLE + " ORDER BY " + COLUMN_ID + " DESC LIMIT 1";

        Cursor cursor = db.rawQuery(query, null);
        String result = null;

        if (cursor.moveToFirst()) {
            result = cursor.getString(cursor.getColumnIndex(columnName));
        }

        cursor.close();
        return result;
    }
    public void deleteAllRecords() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE);
    }

}
