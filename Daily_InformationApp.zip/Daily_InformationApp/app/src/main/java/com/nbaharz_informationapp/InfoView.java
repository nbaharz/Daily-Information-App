package com.nbaharz_informationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

public class InfoView extends AppCompatActivity {
    private HistoryDatabaseHelper historyDatabaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quotes_view);

        historyDatabaseHelper = new HistoryDatabaseHelper(this);

        String receivedValue = getIntent().getStringExtra("INFO");

        TextView txt = findViewById(R.id.textView2);
        txt.setText(receivedValue);

        if(receivedValue!="Today's category hasn't chosen yet.")
            historyDatabaseHelper.addRecord(receivedValue, "RECEIVED_INFO");
    }
}