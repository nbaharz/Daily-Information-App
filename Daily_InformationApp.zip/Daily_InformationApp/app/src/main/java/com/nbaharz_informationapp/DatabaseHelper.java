package com.nbaharz_informationapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private String  INFORMATION_TABLE = "INFORMATION_TABLE";
    private String COLUMN_SCIENCE = "SCIENCE";
    private String COLUMN_MATH = "MATH";
    private String COLUMN_ART = "ART";
    private String COLUMN_PSY = "PSY";
    private String COLUMN_QUOTE = "QUOTE";
    private String COLUMN_ID = "ID"; //ID olmasın


    public DatabaseHelper(@Nullable Context context) {
        super(context, "Information_App.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement="CREATE TABLE " +INFORMATION_TABLE+ "(" +COLUMN_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+ COLUMN_SCIENCE+ " TEXT, "+ COLUMN_MATH+ " TEXT, "+ COLUMN_ART+ " TEXT, " +COLUMN_PSY+ " TEXT, " +COLUMN_QUOTE+ " TEXT)";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addRecord(String text,String columnName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues info = new ContentValues();
        info.put(columnName, text);

        long result = db.insert(INFORMATION_TABLE, null, info);
    }
    @SuppressLint("Range")
    public String getValue(String columnName) {
        String result = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + columnName + " FROM " + INFORMATION_TABLE + " ORDER BY RANDOM() LIMIT 1";

        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            result = cursor.getString(cursor.getColumnIndex(columnName));
        }
        cursor.close();

        return result;
    }
    public void deleteAllRows() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(INFORMATION_TABLE, null, null);
        db.close();
    }

    public String getCOLUMN_ART() {
        return COLUMN_ART;
    }

    public String getCOLUMN_ID() {
        return COLUMN_ID;
    }

    public String getCOLUMN_MATH() {
        return COLUMN_MATH;
    }

    public String getCOLUMN_PSY() {
        return COLUMN_PSY;
    }

    public String getCOLUMN_QUOTE() {
        return COLUMN_QUOTE;
    }

    public String getCOLUMN_SCIENCE() {
        return COLUMN_SCIENCE;
    }

    public String getINFORMATION_TABLE() {
        return INFORMATION_TABLE;
    }
}
