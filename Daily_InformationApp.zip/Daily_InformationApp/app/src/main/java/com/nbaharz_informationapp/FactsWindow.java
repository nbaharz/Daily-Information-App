package com.nbaharz_informationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.util.Log;
import android.widget.Toast;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class FactsWindow extends AppCompatActivity {
    private Connection connection;
    private Button scienceBtn;
    private Button artBtn;
    private Button mathBtn;
    private Button psyBtn;
    private float textSize = 18;
    private DatabaseHelper databaseHelper;
    private OpenNewActivity pageNavigator = new OpenNewActivity(this);

    private boolean isCategorySelected = false;
    private SharedPreferences preferences;
    private PreferencesManager preferencesManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facts_window);

        databaseHelper = new DatabaseHelper(FactsWindow.this);
        SQLiteDatabase db = databaseHelper.getWritableDatabase(); // veya getReadableDatabase()

        preferencesManager = new PreferencesManager(getApplicationContext());
        final String currentDate = preferencesManager.currentDate();
        final String lastCheckedDate = preferencesManager.getLastCheckedDate();

        // If date has changed new category can be selected
        if (!currentDate.equals(lastCheckedDate)) {
            isCategorySelected = false;
        } else {
            // If the  last checked date is same and a category is already chosen, user can't choose category anymore for today.
            isCategorySelected = true;
        }
        Log.d("Dates","Current Date:"+currentDate);
        Log.d("Dates","Last Checked Date:"+lastCheckedDate);


        scienceBtn = findViewById(R.id.science);
        scienceBtn.setTextColor(Color.WHITE);
        scienceBtn.setTextSize(textSize);
        scienceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isCategorySelected) {
                    String scienceValue = databaseHelper.getValue(databaseHelper.getCOLUMN_SCIENCE());
                    pageNavigator.openNewPage(InfoView.class, scienceValue);
                    preferencesManager.saveLastCheckedDate(currentDate);
                    isCategorySelected = true;
                }
                else{
                    Toast.makeText(FactsWindow.this, "Category already s elected", Toast.LENGTH_SHORT).show();
                }

            }
        });

        artBtn = findViewById(R.id.art);
        artBtn.setTextColor(Color.WHITE);
        artBtn.setTextSize(textSize);
        artBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isCategorySelected) {
                    String artValue = databaseHelper.getValue(databaseHelper.getCOLUMN_ART());
                    preferencesManager.saveLastCheckedDate(currentDate);

                    pageNavigator.openNewPage(InfoView.class, artValue);
                    isCategorySelected = true;

                }
                else{
                    Toast.makeText(FactsWindow.this, "Category already selected", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mathBtn = findViewById(R.id.math);
        mathBtn.setTextColor(Color.WHITE);
        mathBtn.setTextSize(textSize);
        mathBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isCategorySelected) {
                    String mathValue = databaseHelper.getValue(databaseHelper.getCOLUMN_MATH());
                    pageNavigator.openNewPage(InfoView.class, mathValue);
                    preferencesManager.saveLastCheckedDate(currentDate);

                    isCategorySelected = true;

                }
                else{
                    Toast.makeText(FactsWindow.this, "Category already selected", Toast.LENGTH_SHORT).show();
                }
            }
        });

        psyBtn = findViewById(R.id.psy);
        psyBtn.setTextColor(Color.WHITE);
        psyBtn.setTextSize(textSize);
        psyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isCategorySelected) {
                    String psyValue = databaseHelper.getValue(databaseHelper.getCOLUMN_PSY());
                    pageNavigator.openNewPage(InfoView.class, psyValue);
                    preferencesManager.saveLastCheckedDate(currentDate);
                    isCategorySelected = true;
                }
                else{
                    Toast.makeText(FactsWindow.this, "Category already selected", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
