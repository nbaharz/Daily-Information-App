package com.nbaharz_informationapp;

import android.content.Context;
import android.content.Intent;

public class OpenNewActivity {

    private Context context;
    public OpenNewActivity(Context context){
        this.context=context;
    }
    public void openNewPage(Class<?> newActivity,String info) {
        Intent intent = new Intent(context, newActivity);
        intent.putExtra("INFO",info);
        context.startActivity(intent);
    }
    public void openNewPage(Class<?> newActivity) {
        Intent intent = new Intent(context, newActivity);
        context.startActivity(intent);
    }
}
